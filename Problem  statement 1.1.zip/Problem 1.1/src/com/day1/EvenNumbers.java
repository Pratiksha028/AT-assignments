package com.day1;

import java.util.Scanner;

public class EvenNumbers {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the number");
		Scanner s= new Scanner(System.in);
		int n = s.nextInt();
			

		System.out.print("Even Numbers from 1 to "+n+" are: ");

		for (int i = 1; i <= n; i++) {

		   //if number%2 == 0 it means its an even number

		   if (i % 2 == 0) {

		 System.out.print(i + " ");

		   }

		}



	}

}
