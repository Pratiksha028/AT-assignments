package com.day1;

public class Rectanglemodify {

}
