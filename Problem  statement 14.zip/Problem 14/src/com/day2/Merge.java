package com.day2;

import java.util.Arrays;

public class Merge {
	public static void sortedMerge(int a[], int b[],
			int res[], int n,
			int m)
{
// Concatenate two arrays
int i = 0, j = 0, k = 0;
while (i < n) {
res[k] = a[i];
i++;
k++;
}

while (j < m) {
res[k] = b[j];
j++;
k++;
}


Arrays.sort(res);
}


public static void main(String[] args)
{
int a[] = { 10, 5, 15 };
System.out.println(" First unsorted list "+Arrays.toString(a));
int b[] = { 20, 3, 2, 12 };
System.out.println(" Second  unsorted list "+Arrays.toString(b));


int n = a.length;
int m = b.length;

int res[]=new int[n + m];
sortedMerge(a, b, res, n, m);

System.out.print(" Sorted merged list :");
for (int i = 0; i < n + m; i++)
System.out.print(" " + res[i]);
}


}
