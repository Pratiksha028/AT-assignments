package com.day2;

import java.util.ArrayDeque;
import java.util.Deque;

public class BalancedBrackets {
	static boolean areBracketsBalanced(String expr)
	{
		Deque<Character> stack
			= new ArrayDeque<Character>();

		for (int i = 0; i < expr.length(); i++)
		{
			char x = expr.charAt(i);

			if (x == '(' || x == '[' || x == '{')
			{
							stack.push(x);   	// Push the element in the stack

				continue;
			}

			// If current character is not opening
			// bracket, then it must be closing. So stack
			// cannot be empty at this point.
			if (stack.isEmpty())
				return false;
			char check;
			switch (x) {
			case ')':
				check = stack.pop();
				if (check == '{' || check == '[')
					return false;
				break;

			case '}':
				check = stack.pop();
				if (check == '(' || check == '[')
					return false;
				break;

			case ']':
				check = stack.pop();
				if (check == '(' || check == '{')
					return false;
				break;
			}
		}

		
		return (stack.isEmpty());    // Check Empty Stack
	}

	public static void main(String[] args)
	{
		String expr = "([{}])";
		System.out.println(" Given Expresion "+ expr);

		if (areBracketsBalanced( expr))
			System.out.println(" Brackets are Balanced ");
		else
			System.out.println(" Brackets are Not Balanced ");
	}

}
