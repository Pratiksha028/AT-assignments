package com.day1;

public class NextSequence {

}
