package com.day1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class StudentList {
	
	
	public static void main(String[] args) {
		ArrayList<String> alist=new ArrayList<String>();//Creating arraylist  
	    alist.add("Raavi");//Adding object in arraylist  
	    alist.add("Viny");  
	    alist.add("Anita");  
	    alist.add("Hema");
	    alist.add("kavya");
	    alist.add("pooja");
	    System.out.println(alist);
	    
	    if (alist.contains("Raavi"))
	        System.out.println("Raavi exists in the ArrayList");

	    else
	        System.out.println("Raavi does not exist in the ArrayList");

	    if (alist.contains("Priya"))
	        System.out.println("Priya exists in the ArrayList");

	    else
	        System.out.println("Priya does not exist in the ArrayList");
	    
	}


}


